import UIKit

class AddCardController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    let storeNameTextField = UITextField()
    let barCodeTextField = UITextField()
    let cardNumberTextField = UITextField()
    let imageView = UIImageView()
    let barImageView = UIImageView()
    let favoritesCheckbox = UISwitch()
    let saveButton = UIButton()
    weak var delegate: AddCardDelegate?
    
    var product = Card(storeName: "", barCode: "", cardNumber: "", image: UIImage(), favorites: false)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageView.layer.masksToBounds = true
        barImageView.layer.masksToBounds = true
        
        imageView.layer.cornerRadius = 8
        barImageView.layer.cornerRadius = 8
        
        setLeftAlignTitleView(font: UIFont(name: "Arial-BoldMT", size: 26)!, text: "My cards", textColor: .white)
        self.navigationController?.view.backgroundColor = hexStringToUIColor(hex: "#12151B")
        self.navigationController?.view.tintColor = .white
        // Set up the text fields, image picker, and checkbox
        imageView.image = UIImage(named: "customImagePlaceholder")
        barImageView.image = UIImage(named: "customImagePlaceholder")
        // Set up the save button
        saveButton.backgroundColor = hexStringToUIColor(hex: "#405EFC")
        saveButton.titleLabel?.font = UIFont(name: "Arial", size: 16)
        saveButton.titleLabel?.textAlignment = .center
        saveButton.setTitleColor(hexStringToUIColor(hex: "FFFFFF"), for: .normal)
        saveButton.layer.cornerRadius = 8
        saveButton.setTitle("Save", for: .normal)
        
        
        storeNameTextField.attributedPlaceholder = NSAttributedString(
            string: "Store name",
            attributes: [NSAttributedString.Key.foregroundColor: hexStringToUIColor(hex: "#838390")]
        )
        storeNameTextField.font = UIFont(name: "Arial", size: 16)
        storeNameTextField.layer.borderWidth = 1
        storeNameTextField.textColor = .white
        storeNameTextField.layer.borderColor = hexStringToUIColor(hex: "#3D485C").cgColor
        storeNameTextField.indent(size: 16)
        storeNameTextField.autocapitalizationType = .none
        storeNameTextField.layer.cornerRadius = 8
        
        barCodeTextField.attributedPlaceholder = NSAttributedString(
            string: "Bar code",
            attributes: [NSAttributedString.Key.foregroundColor: hexStringToUIColor(hex: "#838390")]
        )
        barCodeTextField.font = UIFont(name: "Arial", size: 16)
        barCodeTextField.layer.borderWidth = 1
        barCodeTextField.textColor = .white
        barCodeTextField.layer.borderColor = hexStringToUIColor(hex: "#3D485C").cgColor
        barCodeTextField.indent(size: 16)
        barCodeTextField.autocapitalizationType = .none
        barCodeTextField.layer.cornerRadius = 8
        
        cardNumberTextField.attributedPlaceholder = NSAttributedString(
            string: "Card number",
            attributes: [NSAttributedString.Key.foregroundColor: hexStringToUIColor(hex: "#838390")]
        )
        cardNumberTextField.font = UIFont(name: "Arial", size: 16)
        cardNumberTextField.layer.borderWidth = 1
        cardNumberTextField.textColor = .white
        cardNumberTextField.layer.borderColor = hexStringToUIColor(hex: "#3D485C").cgColor
        cardNumberTextField.indent(size: 16)
        cardNumberTextField.autocapitalizationType = .none
        cardNumberTextField.layer.cornerRadius = 8
        
        
        
        
        
        
        // Add the text fields, image picker, checkbox, and save button to the view
        view.addSubview(storeNameTextField)
        view.addSubview(barCodeTextField)
        view.addSubview(cardNumberTextField)
        view.addSubview(imageView)
        view.addSubview(barImageView)
        view.addSubview(favoritesCheckbox)
        view.addSubview(saveButton)
        
        // Add constraints
        storeNameTextField.translatesAutoresizingMaskIntoConstraints = false
        barCodeTextField.translatesAutoresizingMaskIntoConstraints = false
        cardNumberTextField.translatesAutoresizingMaskIntoConstraints = false
        imageView.translatesAutoresizingMaskIntoConstraints = false
        barImageView.translatesAutoresizingMaskIntoConstraints = false
        favoritesCheckbox.translatesAutoresizingMaskIntoConstraints = false
        saveButton.translatesAutoresizingMaskIntoConstraints = false
        
        let margins = view.layoutMarginsGuide
        
        NSLayoutConstraint.activate([
            storeNameTextField.topAnchor.constraint(equalTo: margins.topAnchor, constant: 24),
            storeNameTextField.leftAnchor.constraint(equalTo: margins.leftAnchor, constant: 8),
            storeNameTextField.rightAnchor.constraint(equalTo: margins.rightAnchor, constant: -8),
            storeNameTextField.heightAnchor.constraint(equalToConstant: 46),
            
            barCodeTextField.topAnchor.constraint(equalTo: storeNameTextField.bottomAnchor, constant: 24),
            barCodeTextField.leftAnchor.constraint(equalTo: margins.leftAnchor, constant: 8),
            barCodeTextField.rightAnchor.constraint(equalTo: margins.rightAnchor, constant: -8),
            barCodeTextField.heightAnchor.constraint(equalToConstant: 46),
            
            cardNumberTextField.topAnchor.constraint(equalTo: barCodeTextField.bottomAnchor, constant: 24),
            cardNumberTextField.leftAnchor.constraint(equalTo: margins.leftAnchor, constant: 8),
            cardNumberTextField.rightAnchor.constraint(equalTo: margins.rightAnchor, constant: -8),
            cardNumberTextField.heightAnchor.constraint(equalToConstant: 46),

            imageView.topAnchor.constraint(equalTo: cardNumberTextField.bottomAnchor, constant: 24),
            imageView.leftAnchor.constraint(equalTo: cardNumberTextField.leftAnchor),
            imageView.heightAnchor.constraint(equalToConstant: self.view.frame.height / 8.5),
            imageView.widthAnchor.constraint(equalToConstant: (self.view.frame.width - 72) / 2),
            
            barImageView.topAnchor.constraint(equalTo: imageView.topAnchor),
            barImageView.rightAnchor.constraint(equalTo: cardNumberTextField.rightAnchor),
            barImageView.heightAnchor.constraint(equalToConstant: self.view.frame.height / 8.5),
            barImageView.widthAnchor.constraint(equalToConstant: (self.view.frame.width - 72) / 2),
        

            favoritesCheckbox.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 24),
            favoritesCheckbox.leftAnchor.constraint(equalTo: imageView.leftAnchor),

            saveButton.centerYAnchor.constraint(equalTo: favoritesCheckbox.centerYAnchor),
            saveButton.leftAnchor.constraint(equalTo: favoritesCheckbox.rightAnchor, constant: 24),
            saveButton.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -24),
            saveButton.heightAnchor.constraint(equalToConstant: 46),
            ])
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(didTapImageView))
        imageView.isUserInteractionEnabled = true
        imageView.addGestureRecognizer(tapGestureRecognizer)
        
        let tapGestureRecognizerBarImage = UITapGestureRecognizer(target: self, action: #selector(didTapBarImageView))
        barImageView.isUserInteractionEnabled = true
        barImageView.addGestureRecognizer(tapGestureRecognizerBarImage)
        
        saveButton.addTarget(self, action: #selector(saveButtonTapped), for: .touchUpInside)
    }
    
    @objc func didTapImageView() {
        // Open the image picker
        let imagePicker = UIImagePickerController()
        imagePicker.view.tag = 1
        imagePicker.delegate = self
        //imagePicker.allowsEditing = true
        present(imagePicker, animated: true)
    }
    
    @objc func didTapBarImageView() {
        // Open the image picker
        let imagePicker = UIImagePickerController()
        imagePicker.view.tag = 2
        imagePicker.delegate = self
        //imagePicker.allowsEditing = true
        present(imagePicker, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        // Dismiss the image picker
        dismiss(animated: true)
        
        // Get the selected image
        guard let selectedImage = info[.originalImage] as? UIImage else {
            return
        }
        if (picker.view.tag == 1) {
            imageView.image = selectedImage
        } else {
            barImageView.image = selectedImage
        }
        // Update the image view with the selected image
    }

    
    @objc func saveButtonTapped() {
        print("hi@")
            product.storeName = storeNameTextField.text ?? ""
            product.barCode = barCodeTextField.text ?? ""
            product.cardNumber = cardNumberTextField.text ?? ""
            product.image = imageView.image!
        product.barImage = barImageView.image!
        if favoritesCheckbox.isOn {
            product.favorites = true
        }
        delegate?.addedCard(card: product)
        self.navigationController?.popViewController(animated: true)
//        let vc = CardsController()
//        dismiss(animated: true, completion: {
//            vc.cardsArray.append(self.product)
//                    })
    }
}

protocol AddCardDelegate : class {
    func addedCard(card: Card)
}
