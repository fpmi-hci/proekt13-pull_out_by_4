import UIKit

struct Card {
    var storeName: String
    var barCode: String
    var cardNumber: String
    var image: UIImage
    var barImage: UIImage?
    var favorites: Bool
}

class CardsController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    let reuseIdentifier = "cell"
    var favoritesFlag = false
    
    var cardsArray = [Card]()
    var cardsArrayFavorites = [Card]()
    
    let allCardsButton = UIButton()
    let favoritesButton = UIButton()
    
    // create a collection view and set its constraints
    let collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.translatesAutoresizingMaskIntoConstraints = false
        return cv
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cardsArray = getProducts()
        for i in cardsArray {
            if (i.favorites == true) {
                cardsArrayFavorites.append(i)
            }
        }
        allCardsButton.backgroundColor = hexStringToUIColor(hex: "#405EFC")
        allCardsButton.setTitle("All cards", for: .normal)
        allCardsButton.titleLabel?.textColor = .white
        allCardsButton.titleLabel?.font = UIFont(name: "Arial", size: 16)
        allCardsButton.layer.cornerRadius = 20
        allCardsButton.addTarget(self, action: #selector(allCardsButtonClick), for: .touchUpInside)
        
        favoritesButton.backgroundColor = hexStringToUIColor(hex: "#242B37")
        favoritesButton.setTitle("Favorites", for: .normal)
        favoritesButton.titleLabel?.textColor = .white
        favoritesButton.setTitleColor(.white, for: .normal)
        favoritesButton.titleLabel?.font = UIFont(name: "Arial", size: 16)
        favoritesButton.layer.cornerRadius = 20
        favoritesButton.addTarget(self, action: #selector(favoritesButtonClick), for: .touchUpInside)
        
        allCardsButton.translatesAutoresizingMaskIntoConstraints = false
        favoritesButton.translatesAutoresizingMaskIntoConstraints = false
        
        self.view.backgroundColor = hexStringToUIColor(hex: "#12151B")
        // Настраиваем навигационное бар с надписью "My cards" слева
        setLeftAlignTitleView(font: UIFont(name: "Arial-BoldMT", size: 26)!, text: "My cards", textColor: .white)
        self.navigationController?.view.backgroundColor = hexStringToUIColor(hex: "#12151B")

        // Создаем кнопку с иконкой плюса
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addButtonTapped))
        addButton.tintColor = .white

        // Добавляем кнопку справа в навигационное бар
        self.navigationItem.rightBarButtonItem = addButton
        
        self.view.addSubview(allCardsButton)
        self.view.addSubview(favoritesButton)
        
        NSLayoutConstraint.activate([
            allCardsButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 5),
            allCardsButton.heightAnchor.constraint(equalToConstant: 35),
            allCardsButton.widthAnchor.constraint(equalToConstant: 94),
            allCardsButton.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 24),
            favoritesButton.topAnchor.constraint(equalTo: allCardsButton.topAnchor),
            favoritesButton.heightAnchor.constraint(equalToConstant: 35),
            favoritesButton.widthAnchor.constraint(equalToConstant: 94),
            favoritesButton.leftAnchor.constraint(equalTo: allCardsButton.rightAnchor, constant: 8),
        ])
        
        
        
        collectionView.backgroundColor = hexStringToUIColor(hex: "#12151B")
        
        // register the cell class and its reuse identifier
        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        
        // set the collection view's data source and delegate
        collectionView.dataSource = self
        collectionView.delegate = self
        
        // add the collection view to the view hierarchy and set its constraints
        view.addSubview(collectionView)
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: allCardsButton.bottomAnchor, constant: 24),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            collectionView.leftAnchor.constraint(equalTo: allCardsButton.leftAnchor),
            collectionView.rightAnchor.constraint(equalTo: view.rightAnchor)
        ])
    }
    
    
    @objc func allCardsButtonClick() {
        favoritesFlag = false
        allCardsButton.backgroundColor = hexStringToUIColor(hex: "#405EFC")
        favoritesButton.backgroundColor = hexStringToUIColor(hex: "#242B37")
        self.collectionView.reloadData()
    }
    
    @objc func favoritesButtonClick() {
        favoritesFlag = true
        allCardsButton.backgroundColor = hexStringToUIColor(hex: "#242B37")
        favoritesButton.backgroundColor = hexStringToUIColor(hex: "#405EFC")
        self.collectionView.reloadData()
    }
    
    func saveProducts(_ products: [Card]) {
        // Encode the products array as Data
        guard let encodedData = try? NSKeyedArchiver.archivedData(withRootObject: products, requiringSecureCoding: false) else { return }
        
        // Save the encoded data to UserDefaults
        UserDefaults.standard.set(encodedData, forKey: "cards")
    }
    
    func getProducts() -> [Card] {
        // Get the encoded data from UserDefaults
        guard let encodedData = UserDefaults.standard.data(forKey: "cards") else {
            return []
        }
        
        // Decode the data into an array of products
        
   
        
        guard let products = try? NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(encodedData) as? [Card] else {
            return []
        }
        
        return products
    }


    @objc func addButtonTapped() {
        // Код, который будет выполняться при нажатии на кнопку с иконкой плюса
        // Например, открытие другого контроллера
        let otherViewController = AddCardController()
        otherViewController.delegate = self
        otherViewController.modalPresentationStyle = .fullScreen
        self.navigationController?.pushViewController(otherViewController, animated: true)
    }

    
    // MARK: - UICollectionViewDataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if (!favoritesFlag) {
            return cardsArray.count
        } else {
            return cardsArrayFavorites.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        var card: Card
        if (!favoritesFlag) {
            card = cardsArray[indexPath.row]
        } else {
            card = cardsArrayFavorites[indexPath.row]
        }
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath)
        cell.backgroundColor = hexStringToUIColor(hex: "#12151B")
        
        let imageViewTmp = UIImageView(image: card.image)
        imageViewTmp.layer.masksToBounds = true
        imageViewTmp.layer.cornerRadius = 8
        
        cell.contentView.addSubview(imageViewTmp)
        imageViewTmp.translatesAutoresizingMaskIntoConstraints = false
        imageViewTmp.leftAnchor.constraint(equalTo: cell.contentView.safeAreaLayoutGuide.leftAnchor).isActive = true
        imageViewTmp.rightAnchor.constraint(equalTo: cell.contentView.safeAreaLayoutGuide.rightAnchor, constant: -24).isActive = true
        imageViewTmp.topAnchor.constraint(equalTo: cell.contentView.topAnchor).isActive = true
        imageViewTmp.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -24).isActive = true
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
        {
                // In this function is the code you must implement to your code project if you want to change size of Collection view
            return CGSize(width: (self.collectionView.frame.width - 10) / 2, height: (self.view.frame.height - 10) / 7)
        }
    
    // MARK: - UICollectionViewDelegate
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("Start")
        var card: Card
        if (!favoritesFlag) {
            card = cardsArray[indexPath.row]
        } else {
            card = cardsArrayFavorites[indexPath.row]
        }
        print(cardsArray[indexPath.row])
        let vc = ShowItemController(card: card)
        print("Next")
        vc.modalPresentationStyle = .fullScreen
        print("Push Controller")
        self.navigationController?.pushViewController(vc, animated: true)
        print("Pushed")
    }
}

extension UIViewController {
    func setLeftAlignTitleView(font: UIFont, text: String, textColor: UIColor) {
        guard let navFrame = navigationController?.navigationBar.frame else{
            return
        }
        
        let parentView = UIView(frame: CGRect(x: 0, y: 0, width: navFrame.width*3, height: navFrame.height))
        self.navigationItem.titleView = parentView
        
        let label = UILabel(frame: .init(x: parentView.frame.minX + 20, y: parentView.frame.minY, width: parentView.frame.width, height: parentView.frame.height))
        label.backgroundColor = .clear
        label.numberOfLines = 2
        label.font = font
        label.textAlignment = .left
        //titleLabel.textAlignment = .left
        label.textColor = textColor
        label.text = text
        
        parentView.addSubview(label)
    }
}

extension CardsController: AddCardDelegate {
    func addedCard(card: Card) {
        if (card.favorites != false) {
            cardsArrayFavorites.append(card)
        }
        cardsArray.append(card)
        collectionView.reloadData()
        saveProducts(cardsArray)
    }
}
