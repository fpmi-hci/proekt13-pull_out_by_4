

import UIKit

class LoginController: UIViewController {

    let titleLabel = UILabel()
    let emailField = UITextField()
    let passwordField = UITextField()
    let signInButton = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = hexStringToUIColor(hex: "#12151B")
        
        titleLabel.textColor = UIColor(red: 255, green: 255, blue: 255, alpha: 1.0)
        titleLabel.font = UIFont(name: "Arial-BoldMT", size: 26)
        titleLabel.textAlignment = .left
        titleLabel.numberOfLines = 1
        titleLabel.text = "Sign in"
        //titleLabel.bold()
        
        self.view.addSubview(titleLabel)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 24).isActive = true
        titleLabel.rightAnchor.constraint(equalTo: self.view.rightAnchor, constant: -24).isActive = true
        titleLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 108).isActive = true
    
        emailField.attributedPlaceholder = NSAttributedString(
            string: "Username",
            attributes: [NSAttributedString.Key.foregroundColor: hexStringToUIColor(hex: "#838390")]
        )
        emailField.layer.cornerRadius = 8
        emailField.font = UIFont(name: "Arial", size: 16)
        emailField.layer.borderWidth = 1
        emailField.textColor = .white
        emailField.layer.borderColor = hexStringToUIColor(hex: "#3D485C").cgColor
        emailField.indent(size: 16)
        emailField.autocapitalizationType = .none
        
        self.view.addSubview(emailField)
        emailField.translatesAutoresizingMaskIntoConstraints = false
        emailField.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 24).isActive = true
        emailField.rightAnchor.constraint(equalTo: self.view.rightAnchor, constant: -24).isActive = true
        emailField.topAnchor.constraint(equalTo: self.titleLabel.bottomAnchor, constant: 27).isActive = true
        emailField.heightAnchor.constraint(equalToConstant: 46).isActive = true
        
        passwordField.attributedPlaceholder = NSAttributedString(
            string: "Password",
            attributes: [NSAttributedString.Key.foregroundColor: hexStringToUIColor(hex: "#838390")]
        )
        passwordField.layer.cornerRadius = 8
        passwordField.font = UIFont(name: "Arial", size: 16)
        passwordField.textColor = .white
        passwordField.layer.borderWidth = 1
        passwordField.layer.borderColor = hexStringToUIColor(hex: "#3D485C").cgColor
        passwordField.indent(size: 16)
        passwordField.autocapitalizationType = .none
        passwordField.isSecureTextEntry = true
        
        self.view.addSubview(passwordField)
        passwordField.translatesAutoresizingMaskIntoConstraints = false
        passwordField.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 24).isActive = true
        passwordField.rightAnchor.constraint(equalTo: self.view.rightAnchor, constant: -24).isActive = true
        passwordField.topAnchor.constraint(equalTo: self.emailField.bottomAnchor, constant: 24).isActive = true
        passwordField.heightAnchor.constraint(equalToConstant: 46).isActive = true
        
        
        signInButton.backgroundColor = hexStringToUIColor(hex: "#405EFC")
        signInButton.titleLabel?.font = UIFont(name: "Arial", size: 16)
        signInButton.titleLabel?.textAlignment = .center
        signInButton.setTitleColor(hexStringToUIColor(hex: "FFFFFF"), for: .normal)
        signInButton.setTitle("Sign in", for: .normal)
        signInButton.layer.cornerRadius = 8
        signInButton.addTarget(self, action: #selector(signInButtonTapped), for: .touchUpInside)
        
        self.view.addSubview(signInButton)
        signInButton.translatesAutoresizingMaskIntoConstraints = false
        signInButton.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 24).isActive = true
        signInButton.rightAnchor.constraint(equalTo: self.view.rightAnchor, constant: -24).isActive = true
        signInButton.topAnchor.constraint(equalTo: self.passwordField.bottomAnchor, constant: 56).isActive = true
        signInButton.heightAnchor.constraint(equalToConstant: 46).isActive = true
    }

      // MARK: - Actions

      @objc private func signInButtonTapped() {
        guard let username = emailField.text, !username.isEmpty else {
//          errorLabel.text = "Please enter a username."
//          errorLabel.isHidden = false
            print("Please enter a username.")
          return
        }

        guard let password = passwordField.text, !password.isEmpty else {
//          errorLabel.text = "Please enter a password."
//          errorLabel.isHidden = false
            print("Please enter a password.")
          return
        }

        // Validate the login credentials
        let isValid = validate(username: username, password: password)

        if isValid {
          // Save the login credentials
          save(username: username, password: password)
          // Dismiss the login screen
            // example ViewController
            let myVC = CardsController()
            myVC.modalPresentationStyle = .fullScreen
            // create the NavigationController with my VC as root
            let navCon = UINavigationController(rootViewController: myVC)
            navCon.modalPresentationStyle = .fullScreen
            self.present(navCon, animated: true, completion: nil)
        } else {
//          errorLabel.text = "Invalid username or password."
//          errorLabel.isHidden = false
            print("Invalid username or password.")
        }
      }

      // MARK: - Helper Methods

      private func validate(username: String, password: String) -> Bool {
        // Validate the login credentials here
        // For example, you can check if the username and password match a pre-defined set of credentials

        let isValid = (username == "test" && password == "test")  // Replace this with your validation logic

        return isValid
      }

    private func save(username: String, password: String) {
      // Save the login credentials to the user defaults
      UserDefaults.standard.set(username, forKey: "username")
      UserDefaults.standard.set(password, forKey: "password")
      UserDefaults.standard.synchronize()
    }


}

extension UILabel{
    func bold() -> UILabel {
        if let descriptor = self.font.fontDescriptor.withSymbolicTraits(UIFontDescriptor.SymbolicTraits.traitBold){
            self.font = UIFont(descriptor: descriptor, size: 0)
        }
        return self
    }
}

extension UITextField {
    func indent(size:CGFloat) {
        self.leftView = UIView(frame: CGRect(x: self.frame.minX, y: self.frame.minY, width: size, height: self.frame.height))
        self.leftViewMode = .always
    }
}


