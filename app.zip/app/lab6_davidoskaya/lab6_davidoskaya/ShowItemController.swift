

import UIKit

class ShowItemController: UIViewController {

    var card:Card? = nil
    let mainImageView = UIImageView()
    let barImageView = UIImageView()
    let cardNumberLabel = UILabel()
    
    init(card: Card?)
    {
        self.card = card

        super.init(nibName: nil, bundle: nil)
    }

    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = hexStringToUIColor(hex: "#12151B")
        setLeftAlignTitleView(font: UIFont(name: "Arial-BoldMT", size: 26)!, text: card!.storeName, textColor: .white)
        
        mainImageView.image = card!.image
        barImageView.image = card!.barImage
        
        mainImageView.layer.masksToBounds = true
        barImageView.layer.masksToBounds = true
        
        mainImageView.layer.cornerRadius = 8
        barImageView.layer.cornerRadius = 8
        
        cardNumberLabel.text = "\(card!.barCode) \(card!.cardNumber)"
        
        cardNumberLabel.font = UIFont(name: "Arial-BoldMT", size: 16)
        cardNumberLabel.textColor = .white
        cardNumberLabel.textAlignment = .center
        self.view.addSubview(mainImageView)
        self.view.addSubview(barImageView)
        self.view.addSubview(cardNumberLabel)
        mainImageView.translatesAutoresizingMaskIntoConstraints = false
        barImageView.translatesAutoresizingMaskIntoConstraints = false
        cardNumberLabel.translatesAutoresizingMaskIntoConstraints = false
        mainImageView.leftAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.leftAnchor, constant: 24).isActive = true
        mainImageView.rightAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.rightAnchor, constant: -24).isActive = true
        mainImageView.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 24).isActive = true
        mainImageView.heightAnchor.constraint(equalToConstant: self.view.frame.height / 4).isActive = true
        
        barImageView.leftAnchor.constraint(equalTo: mainImageView.leftAnchor).isActive = true
        barImageView.rightAnchor.constraint(equalTo: mainImageView.rightAnchor).isActive = true
        barImageView.topAnchor.constraint(equalTo: mainImageView.bottomAnchor, constant: 24).isActive = true
        barImageView.heightAnchor.constraint(equalToConstant: self.view.frame.height / 8).isActive = true
        
        cardNumberLabel.leftAnchor.constraint(equalTo: mainImageView.leftAnchor).isActive = true
        cardNumberLabel.rightAnchor.constraint(equalTo: mainImageView.rightAnchor).isActive = true
        cardNumberLabel.topAnchor.constraint(equalTo: barImageView.bottomAnchor, constant: 24).isActive = true
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
