

import UIKit

class WelcomeController: UIViewController {

    let titleLabel = UILabel()
    let descriptionLabel = UILabel()
    let getStartedButton = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = hexStringToUIColor(hex: "#12151B")
        
        getStartedButton.backgroundColor = hexStringToUIColor(hex: "#405EFC")
        getStartedButton.titleLabel?.font = UIFont(name: "Arial", size: 16)
        getStartedButton.titleLabel?.textAlignment = .center
        getStartedButton.setTitleColor(hexStringToUIColor(hex: "FFFFFF"), for: .normal)
        getStartedButton.setTitle("Get Started", for: .normal)
        getStartedButton.layer.cornerRadius = 8
        getStartedButton.addTarget(self, action: #selector(presentLoginController), for: .touchUpInside)
        
        descriptionLabel.textColor = UIColor(red: 255, green: 255, blue: 255, alpha: 0.8)
        descriptionLabel.font = UIFont(name: "Arial", size: 16)
        descriptionLabel.textAlignment = .left
        descriptionLabel.numberOfLines = 2
        descriptionLabel.text = "This is your own wallet. Save your existing\nand new discount cards for free."
        
        titleLabel.textColor = UIColor(red: 255, green: 255, blue: 255, alpha: 1.0)
        titleLabel.font = UIFont(name: "Arial", size: 28)
        titleLabel.textAlignment = .left
        titleLabel.numberOfLines = 2
        titleLabel.text = "Your personal\nwallet"
        
        self.view.addSubview(getStartedButton)
        getStartedButton.translatesAutoresizingMaskIntoConstraints = false
        getStartedButton.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 24).isActive = true
        getStartedButton.rightAnchor.constraint(equalTo: self.view.rightAnchor, constant: -24).isActive = true
        getStartedButton.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -35).isActive = true
        getStartedButton.heightAnchor.constraint(equalToConstant: 46).isActive = true
        
        self.view.addSubview(descriptionLabel)
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        descriptionLabel.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 24).isActive = true
        descriptionLabel.rightAnchor.constraint(equalTo: self.view.rightAnchor, constant: -24).isActive = true
        descriptionLabel.bottomAnchor.constraint(equalTo: getStartedButton.topAnchor, constant: -95).isActive = true
        
        self.view.addSubview(titleLabel)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 24).isActive = true
        titleLabel.rightAnchor.constraint(equalTo: self.view.rightAnchor, constant: -24).isActive = true
        titleLabel.bottomAnchor.constraint(equalTo: descriptionLabel.topAnchor, constant: -16).isActive = true
    }

    @objc func presentLoginController() {
        let loginController = LoginController()
        loginController.modalPresentationStyle = .fullScreen
        self.present(loginController, animated: true, completion: nil)
    }
}

extension UIViewController {
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }

        if ((cString.count) != 6) {
            return UIColor.gray
        }

        var rgbValue:UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)

        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}
